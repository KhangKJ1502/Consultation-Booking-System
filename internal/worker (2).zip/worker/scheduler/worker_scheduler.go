package scheduler

import (
	"cbs_backend/internal/worker/notification"
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/robfig/cron/v3"
)

// WorkerScheduler manages and schedules jobs
type WorkerScheduler struct {
	jobProcessor *JobProcessor
	jobQueue     chan *Job
	workerCount  int
	stopChan     chan struct{}
	wg           sync.WaitGroup
	cron         *cron.Cron
}

// NewWorkerScheduler creates a new worker scheduler
func NewWorkerScheduler(jobProcessor *JobProcessor, workerCount int) *WorkerScheduler {
	return &WorkerScheduler{
		jobProcessor: jobProcessor,
		jobQueue:     make(chan *Job, 1000), // Buffer size of 1000
		workerCount:  workerCount,
		stopChan:     make(chan struct{}),
		cron:         cron.New(),
	}
}

// Start starts the worker scheduler and cron jobs
func (ws *WorkerScheduler) Start(ctx context.Context) error {
	log.Printf("🚀 Starting worker scheduler with %d workers", ws.workerCount)

	// Start worker goroutines
	for i := 0; i < ws.workerCount; i++ {
		ws.wg.Add(1)
		go ws.worker(ctx, i)
	}

	// Setup cron jobs
	err := ws.setupCronJobs()
	if err != nil {
		return fmt.Errorf("failed to setup cron jobs: %w", err)
	}

	ws.cron.Start()
	return nil
}

// Stop stops the worker scheduler and cron jobs
func (ws *WorkerScheduler) Stop() {
	log.Println("🛑 Stopping worker scheduler...")
	close(ws.stopChan)

	if ws.cron != nil {
		ws.cron.Stop()
	}

	ws.wg.Wait()
	log.Println("✅ Worker scheduler stopped")
}

// setupCronJobs configures scheduled cron jobs
func (ws *WorkerScheduler) setupCronJobs() error {
	// Mỗi 10 phút gửi nhắc nhở
	_, err := ws.cron.AddFunc("*/10 * * * *", func() {
		log.Println("🔁 Cron job: Schedule reminders")
		ws.scheduleReminderJobs()
	})
	if err != nil {
		return err
	}

	// Mỗi ngày lúc 00:00 kiểm tra booking hết hạn
	_, err = ws.cron.AddFunc("0 0 * * *", func() {
		log.Println("🔁 Cron job: Check expired bookings")
		ws.schedulePeriodicTasks()
	})
	return err
}

// ScheduleJob schedules a job for execution
func (ws *WorkerScheduler) ScheduleJob(job *Job) error {
	select {
	case ws.jobQueue <- job:
		log.Printf("📥 Job %s scheduled successfully", job.ID)
		return nil
	default:
		return fmt.Errorf("job queue is full")
	}
}

// worker processes jobs from the job queue
func (ws *WorkerScheduler) worker(ctx context.Context, workerID int) {
	defer ws.wg.Done()
	log.Printf("👷 Worker %d started", workerID)

	for {
		select {
		case job := <-ws.jobQueue:
			ws.processJobWithRetry(ctx, job, workerID)
		case <-ws.stopChan:
			log.Printf("👷 Worker %d stopping", workerID)
			return
		case <-ctx.Done():
			log.Printf("👷 Worker %d stopping due to context cancellation", workerID)
			return
		}
	}
}

// processJobWithRetry processes a job with retry logic
func (ws *WorkerScheduler) processJobWithRetry(ctx context.Context, job *Job, workerID int) {
	log.Printf("⚙️ Worker %d processing job %s", workerID, job.ID)

	err := ws.jobProcessor.ProcessJob(ctx, job)
	if err != nil {
		log.Printf("❌ Worker %d failed to process job %s: %v", workerID, job.ID, err)

		// Retry logic
		if job.RetryCount < job.MaxRetries {
			job.RetryCount++
			log.Printf("🔁 Retrying job %s (attempt %d/%d)", job.ID, job.RetryCount, job.MaxRetries)

			// Schedule retry after a delay
			go func() {
				time.Sleep(time.Duration(job.RetryCount) * time.Minute)
				ws.ScheduleJob(job)
			}()
		} else {
			log.Printf("⛔ Job %s failed after %d attempts", job.ID, job.MaxRetries)
		}
	} else {
		log.Printf("✅ Worker %d successfully processed job %s", workerID, job.ID)
	}
}

// schedulePeriodicTasks schedules periodic maintenance tasks
func (ws *WorkerScheduler) schedulePeriodicTasks() {
	expiredCheckJob := &Job{
		ID:          fmt.Sprintf("expired_check_%d", time.Now().Unix()),
		Type:        JobTypeExpiredCheck,
		Payload:     map[string]interface{}{},
		ScheduledAt: time.Now(),
		CreatedAt:   time.Now(),
		MaxRetries:  3,
	}
	ws.ScheduleJob(expiredCheckJob)
}

// scheduleReminderJobs scans for upcoming reminders and schedules them
func (ws *WorkerScheduler) scheduleReminderJobs() {
	// TODO: Implement logic to fetch upcoming reminders from DB
	// For each reminder, call ScheduleReminderJob()
}

// ScheduleReminderJob creates a job to send a reminder
func (ws *WorkerScheduler) ScheduleReminderJob(bookingID string, reminderData *notification.ReminderData, reminderTime time.Time) error {
	job := &Job{
		ID:   fmt.Sprintf("reminder_%s_%s", bookingID, reminderData.ReminderType),
		Type: JobTypeReminder,
		Payload: map[string]interface{}{
			"booking_id":        reminderData.BookingID,
			"user_id":           reminderData.UserID,
			"expert_id":         reminderData.ExpertID,
			"user_email":        reminderData.UserEmail,
			"expert_email":      reminderData.ExpertEmail,
			"user_name":         reminderData.UserName,
			"expert_name":       reminderData.ExpertName,
			"consultation_time": reminderData.ConsultationTime,
			"reminder_type":     reminderData.ReminderType,
		},
		ScheduledAt: reminderTime,
		CreatedAt:   time.Now(),
		MaxRetries:  3,
	}

	return ws.ScheduleJob(job)
}
