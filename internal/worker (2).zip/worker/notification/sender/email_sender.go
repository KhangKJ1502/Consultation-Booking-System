// worker/notification/sender/email_sender.go
package sender

import (
	"cbs_backend/internal/service/interfaces"
	"context"
	"log"
)

// EmailSender interface
type EmailSender interface {
	SendEmail(ctx context.Context, to, subject, body string, data map[string]interface{}) error
}

// EmailSenderImpl implements EmailSender using the main EmailService
type EmailSenderImpl struct {
	emailService interfaces.EmailService
}

// NewEmailSender creates a new email sender
func NewEmailSender(emailService interfaces.EmailService) *EmailSenderImpl {
	return &EmailSenderImpl{
		emailService: emailService,
	}
}

// SendEmail sends an email using the main email service
func (e *EmailSenderImpl) SendEmail(ctx context.Context, to, subject, body string, data map[string]interface{}) error {
	// For reminder emails, we need to determine the type and call appropriate method
	if reminderType, exists := data["reminder_type"]; exists {
		return e.sendReminderEmail(ctx, to, reminderType.(string), data)
	}

	// For other types of emails, you can add more logic here
	log.Printf("Sending generic email to %s with subject: %s", to, subject)
	return nil
}

// sendReminderEmail sends reminder emails using the EmailService interface
func (e *EmailSenderImpl) sendReminderEmail(ctx context.Context, to, reminderType string, data map[string]interface{}) error {
	userID, _ := data["user_id"].(string)
	expertID, _ := data["expert_id"].(string)

	// Create ConsultationReminderData from the data map
	reminderData := interfaces.ConsultationReminderData{
		BookingID:        data["booking_id"].(string),
		UserName:         data["user_name"].(string),
		ExpertName:       data["expert_name"].(string),
		ConsultationTime: data["consultation_time"].(string), // You might need to format this
		// reminder_type:     reminderType,
	}

	// Determine if this is for user or expert based on the recipient email
	userEmail, _ := data["user_email"].(string)
	if to == userEmail {
		return e.emailService.SendConsultationBookingRemindersToUser(ctx, userID, reminderData)
	} else {
		return e.emailService.SendConsultationBookingRemindersToExpert(ctx, expertID, reminderData)
	}
}
