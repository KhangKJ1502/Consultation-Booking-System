// worker/scheduler/job_processor.go
package scheduler

import (
	"cbs_backend/internal/worker/booking"
	"cbs_backend/internal/worker/notification"

	"context"
	"encoding/json"
	"fmt"
	"log"
	"time"
)

// JobType represents the type of job
type JobType string

const (
	JobTypeReminder     JobType = "reminder"
	JobTypeStatusUpdate JobType = "status_update"
	JobTypeStatsUpdate  JobType = "stats_update"
	JobTypeExpiredCheck JobType = "expired_check"
)

// Job represents a scheduled job
type Job struct {
	ID          string                 `json:"id"`
	Type        JobType                `json:"type"`
	Payload     map[string]interface{} `json:"payload"`
	ScheduledAt time.Time              `json:"scheduled_at"`
	CreatedAt   time.Time              `json:"created_at"`
	RetryCount  int                    `json:"retry_count"`
	MaxRetries  int                    `json:"max_retries"`
}

// JobProcessor processes different types of jobs
type JobProcessor struct {
	reminderService *booking.ReminderService
	statsService    *booking.StatsService
	statusService   *booking.StatusService
}

// NewJobProcessor creates a new job processor
func NewJobProcessor(reminderService *booking.ReminderService, statsService *booking.StatsService, statusService *booking.StatusService) *JobProcessor {
	return &JobProcessor{
		reminderService: reminderService,
		statsService:    statsService,
		statusService:   statusService,
	}
}

// ProcessJob processes a job based on its type
func (p *JobProcessor) ProcessJob(ctx context.Context, job *Job) error {
	log.Printf("Processing job %s of type %s", job.ID, job.Type)

	switch job.Type {
	case JobTypeReminder:
		return p.processReminderJob(ctx, job)
	case JobTypeStatusUpdate:
		return p.processStatusUpdateJob(ctx, job)
	case JobTypeStatsUpdate:
		return p.processStatsUpdateJob(ctx, job)
	case JobTypeExpiredCheck:
		return p.processExpiredCheckJob(ctx, job)
	default:
		return fmt.Errorf("unsupported job type: %s", job.Type)
	}
}

func (p *JobProcessor) processReminderJob(ctx context.Context, job *Job) error {
	// Parse reminder data from job payload
	reminderData := &notification.ReminderData{}

	payloadBytes, err := json.Marshal(job.Payload)
	if err != nil {
		return fmt.Errorf("failed to marshal job payload: %v", err)
	}

	if err := json.Unmarshal(payloadBytes, reminderData); err != nil {
		return fmt.Errorf("failed to unmarshal reminder data: %v", err)
	}

	return p.reminderService.ProcessReminder(ctx, reminderData)
}

func (p *JobProcessor) processStatusUpdateJob(ctx context.Context, job *Job) error {
	bookingID, ok := job.Payload["booking_id"].(string)
	if !ok {
		return fmt.Errorf("missing booking_id in payload")
	}

	statusStr, ok := job.Payload["status"].(string)
	if !ok {
		return fmt.Errorf("missing status in payload")
	}

	status := booking.BookingStatus(statusStr)
	return p.statusService.UpdateBookingStatus(ctx, bookingID, status)
}

func (p *JobProcessor) processStatsUpdateJob(ctx context.Context, job *Job) error {
	bookingID, ok := job.Payload["booking_id"].(string)
	if !ok {
		return fmt.Errorf("missing booking_id in payload")
	}

	action, ok := job.Payload["action"].(string)
	if !ok {
		return fmt.Errorf("missing action in payload")
	}

	return p.statsService.UpdateBookingStats(ctx, bookingID, action)
}

func (p *JobProcessor) processExpiredCheckJob(ctx context.Context, job *Job) error {
	return p.statusService.ProcessExpiredBookings(ctx)
}
