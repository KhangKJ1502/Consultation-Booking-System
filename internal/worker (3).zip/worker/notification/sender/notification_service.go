// worker/notification/sender/notification_service.go
package sender

import (
	"cbs_backend/internal/worker/notification"
	"context"
	"fmt"
)

// NotificationService handles sending notifications through different channels
type NotificationService struct {
	emailSender    EmailSender
	smsSender      SMSSender
	telegramSender TelegramSender
}

// NewNotificationService creates a new notification service
func NewNotificationService(emailSender EmailSender, smsSender SMSSender, telegramSender TelegramSender) *NotificationService {
	return &NotificationService{
		emailSender:    emailSender,
		smsSender:      smsSender,
		telegramSender: telegramSender,
	}
}

// SendNotification sends a notification based on its type
func (s *NotificationService) SendNotification(ctx context.Context, req *notification.NotificationRequest) (*notification.NotificationResponse, error) {
	switch req.Type {
	case notification.NotificationTypeEmail:
		return s.sendEmail(ctx, req)
	case notification.NotificationTypeSMS:
		return s.sendSMS(ctx, req)
	case notification.NotificationTypeTelegram:
		return s.sendTelegram(ctx, req)
	default:
		return nil, fmt.Errorf("unsupported notification type: %s", req.Type)
	}
}

func (s *NotificationService) sendEmail(ctx context.Context, req *notification.NotificationRequest) (*notification.NotificationResponse, error) {
	err := s.emailSender.SendEmail(ctx, req.Recipient, req.Subject, req.Message, req.Data)
	if err != nil {
		return &notification.NotificationResponse{
			ID:      req.ID,
			Success: false,
			Error:   err.Error(),
		}, err
	}

	return &notification.NotificationResponse{
		ID:      req.ID,
		Success: true,
	}, nil
}

func (s *NotificationService) sendSMS(ctx context.Context, req *notification.NotificationRequest) (*notification.NotificationResponse, error) {
	err := s.smsSender.SendSMS(ctx, req.Recipient, req.Message)
	if err != nil {
		return &notification.NotificationResponse{
			ID:      req.ID,
			Success: false,
			Error:   err.Error(),
		}, err
	}

	return &notification.NotificationResponse{
		ID:      req.ID,
		Success: true,
	}, nil
}

func (s *NotificationService) sendTelegram(ctx context.Context, req *notification.NotificationRequest) (*notification.NotificationResponse, error) {
	err := s.telegramSender.SendMessage(ctx, req.Recipient, req.Message)
	if err != nil {
		return &notification.NotificationResponse{
			ID:      req.ID,
			Success: false,
			Error:   err.Error(),
		}, err
	}

	return &notification.NotificationResponse{
		ID:      req.ID,
		Success: true,
	}, nil
}
