// worker/notification/types.go
package notification

import "time"

// NotificationType defines the type of notification
type NotificationType string

const (
	NotificationTypeEmail    NotificationType = "email"
	NotificationTypeSMS      NotificationType = "sms"
	NotificationTypeTelegram NotificationType = "telegram"
)

// NotificationRequest represents a notification request
type NotificationRequest struct {
	ID          string                 `json:"id"`
	Type        NotificationType       `json:"type"`
	Recipient   string                 `json:"recipient"`
	Subject     string                 `json:"subject,omitempty"`
	Message     string                 `json:"message"`
	Data        map[string]interface{} `json:"data,omitempty"`
	ScheduledAt time.Time              `json:"scheduled_at,omitempty"`
	CreatedAt   time.Time              `json:"created_at"`
	RetryCount  int                    `json:"retry_count"`
	MaxRetries  int                    `json:"max_retries"`
}

// NotificationResponse represents the response after sending notification
type NotificationResponse struct {
	ID      string    `json:"id"`
	Success bool      `json:"success"`
	Error   string    `json:"error,omitempty"`
	SentAt  time.Time `json:"sent_at"`
}

// ReminderData holds data for booking reminders
type ReminderData struct {
	BookingID        string    `json:"booking_id"`
	UserID           string    `json:"user_id"`
	ExpertID         string    `json:"expert_id"`
	UserEmail        string    `json:"user_email"`
	ExpertEmail      string    `json:"expert_email"`
	UserName         string    `json:"user_name"`
	ExpertName       string    `json:"expert_name"`
	ConsultationTime time.Time `json:"consultation_time"`
	ReminderType     string    `json:"reminder_type"` // "24h", "1h", "15m"
}
