// worker/booking/reminder_service.go
package booking

import (
	"cbs_backend/internal/worker/notification"
	"cbs_backend/internal/worker/notification/sender"
	"context"
	"fmt"
	"log"
	"time"
)

// ReminderService handles booking reminders
type ReminderService struct {
	notificationService *sender.NotificationService
}

// NewReminderService creates a new reminder service
func NewReminderService(notificationService *sender.NotificationService) *ReminderService {
	return &ReminderService{
		notificationService: notificationService,
	}
}

// ProcessReminder processes a reminder for a booking
func (r *ReminderService) ProcessReminder(ctx context.Context, reminderData *notification.ReminderData) error {
	log.Printf("Processing reminder for booking %s, type: %s", reminderData.BookingID, reminderData.ReminderType)

	// Send reminder to user
	if err := r.sendReminderToUser(ctx, reminderData); err != nil {
		log.Printf("Failed to send reminder to user: %v", err)
		return err
	}

	// Send reminder to expert
	if err := r.sendReminderToExpert(ctx, reminderData); err != nil {
		log.Printf("Failed to send reminder to expert: %v", err)
		return err
	}

	return nil
}

func (r *ReminderService) sendReminderToUser(ctx context.Context, data *notification.ReminderData) error {
	subject := fmt.Sprintf("Reminder: Consultation with %s in %s", data.ExpertName, r.getReminderTimeText(data.ReminderType))
	message := fmt.Sprintf("Dear %s,\n\nThis is a reminder that you have a consultation with %s scheduled for %s.\n\nPlease make sure to join on time.",
		data.UserName, data.ExpertName, data.ConsultationTime.Format("2006-01-02 15:04"))

	notificationReq := &notification.NotificationRequest{
		ID:        fmt.Sprintf("reminder_%s_user_%s", data.BookingID, data.ReminderType),
		Type:      notification.NotificationTypeEmail,
		Recipient: data.UserEmail,
		Subject:   subject,
		Message:   message,
		Data: map[string]interface{}{
			"booking_id":        data.BookingID,
			"user_id":           data.UserID,
			"user_name":         data.UserName,
			"expert_name":       data.ExpertName,
			"consultation_time": data.ConsultationTime.Format("2006-01-02 15:04"),
			"reminder_type":     data.ReminderType,
			"user_email":        data.UserEmail,
		},
		CreatedAt:  time.Now(),
		MaxRetries: 3,
	}

	_, err := r.notificationService.SendNotification(ctx, notificationReq)
	return err
}

func (r *ReminderService) sendReminderToExpert(ctx context.Context, data *notification.ReminderData) error {
	subject := fmt.Sprintf("Reminder: Consultation with %s in %s", data.UserName, r.getReminderTimeText(data.ReminderType))
	message := fmt.Sprintf("Dear %s,\n\nThis is a reminder that you have a consultation with %s scheduled for %s.\n\nPlease make sure to join on time.",
		data.ExpertName, data.UserName, data.ConsultationTime.Format("2006-01-02 15:04"))

	notificationReq := &notification.NotificationRequest{
		ID:        fmt.Sprintf("reminder_%s_expert_%s", data.BookingID, data.ReminderType),
		Type:      notification.NotificationTypeEmail,
		Recipient: data.ExpertEmail,
		Subject:   subject,
		Message:   message,
		Data: map[string]interface{}{
			"booking_id":        data.BookingID,
			"expert_id":         data.ExpertID,
			"user_name":         data.UserName,
			"expert_name":       data.ExpertName,
			"consultation_time": data.ConsultationTime.Format("2006-01-02 15:04"),
			"reminder_type":     data.ReminderType,
			"expert_email":      data.ExpertEmail,
		},
		CreatedAt:  time.Now(),
		MaxRetries: 3,
	}

	_, err := r.notificationService.SendNotification(ctx, notificationReq)
	return err
}

func (r *ReminderService) getReminderTimeText(reminderType string) string {
	switch reminderType {
	case "24h":
		return "24 hours"
	case "1h":
		return "1 hour"
	case "15m":
		return "15 minutes"
	default:
		return reminderType
	}
}
