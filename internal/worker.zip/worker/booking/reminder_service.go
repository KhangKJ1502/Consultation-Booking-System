// worker/booking/reminder_service.go
package booking

import (
	"cbs_backend/internal/service/interfaces"
	"context"
	"fmt"
	"log"
	"time"

	"gorm.io/gorm"
)

type ReminderService struct {
	db           *gorm.DB
	emailService interfaces.EmailService
}

func NewReminderService(db *gorm.DB, emailService interfaces.EmailService) *ReminderService {
	return &ReminderService{
		db:           db,
		emailService: emailService,
	}
}

// SendBookingReminders sends reminders for upcoming bookings
func (rs *ReminderService) SendBookingReminders() error {
	log.Println("🔔 Starting booking reminder process...")

	// Get bookings that need reminders (e.g., 1 day and 1 hour before)
	bookings, err := rs.getBookingsNeedingReminders()
	if err != nil {
		return fmt.Errorf("failed to get bookings needing reminders: %w", err)
	}

	if len(bookings) == 0 {
		log.Println("✅ No bookings need reminders at this time")
		return nil
	}

	log.Printf("📋 Found %d bookings needing reminders", len(bookings))

	// Send reminders for each booking
	for _, booking := range bookings {
		if err := rs.sendReminderForBooking(booking); err != nil {
			log.Printf("❌ Failed to send reminder for booking %s: %v", booking.BookingID, err)
			continue
		}
		log.Printf("✅ Sent reminder for booking %s", booking.BookingID)
	}

	log.Println("✅ Booking reminder process completed")
	return nil
}

// BookingReminderData represents the data needed for booking reminders
type BookingReminderData struct {
	BookingID    string    `json:"booking_id"`
	UserID       string    `json:"user_id"`
	ExpertID     string    `json:"expert_id"`
	UserEmail    string    `json:"user_email"`
	ExpertEmail  string    `json:"expert_email"`
	UserName     string    `json:"user_name"`
	ExpertName   string    `json:"expert_name"`
	BookingTime  time.Time `json:"booking_time"`
	ServiceType  string    `json:"service_type"`
	ServiceTitle string    `json:"service_title"`
	Status       string    `json:"status"`
	ReminderType string    `json:"reminder_type"` // "1_day", "1_hour", "30_min"
	Duration     int       `json:"duration"`      // in minutes
	MeetingLink  string    `json:"meeting_link"`
	Notes        string    `json:"notes"`
}

func (rs *ReminderService) getBookingsNeedingReminders() ([]BookingReminderData, error) {
	var bookings []BookingReminderData

	// Query for bookings that need reminders
	// This query gets bookings that are:
	// 1. Confirmed and upcoming
	// 2. Need 24-hour reminder (booking_time between 23-25 hours from now)
	// 3. Need 1-hour reminder (booking_time between 45-75 minutes from now)
	query := `
		SELECT 
			cb.booking_id,
			cb.user_id,
			cb.expert_id,
			u.user_email,
			u.user_full_name as user_name,
			e.expert_email,
			e.expert_full_name as expert_name,
			cb.consultation_date_time as booking_time,
			cb.consultation_type as service_type,
			cb.consultation_title as service_title,
			cb.consultation_status as status,
			cb.consultation_duration as duration,
			cb.consultation_meeting_link as meeting_link,
			cb.consultation_notes as notes,
			CASE 
				WHEN cb.consultation_date_time BETWEEN NOW() + INTERVAL '23 hours' AND NOW() + INTERVAL '25 hours' THEN '1_day'
				WHEN cb.consultation_date_time BETWEEN NOW() + INTERVAL '45 minutes' AND NOW() + INTERVAL '75 minutes' THEN '1_hour'
				ELSE ''
			END as reminder_type
		FROM tbl_consultation_bookings cb
		JOIN tbl_users u ON cb.user_id = u.user_id
		JOIN tbl_experts e ON cb.expert_id = e.expert_id
		WHERE cb.consultation_status = 'confirmed'
		AND (
			(cb.consultation_date_time BETWEEN NOW() + INTERVAL '23 hours' AND NOW() + INTERVAL '25 hours')
			OR
			(cb.consultation_date_time BETWEEN NOW() + INTERVAL '45 minutes' AND NOW() + INTERVAL '75 minutes')
		)
		AND cb.consultation_date_time > NOW()
		ORDER BY cb.consultation_date_time ASC
	`

	err := rs.db.Raw(query).Scan(&bookings).Error
	if err != nil {
		return nil, fmt.Errorf("failed to query bookings: %w", err)
	}

	return bookings, nil
}

func (rs *ReminderService) sendReminderForBooking(booking BookingReminderData) error {
	ctx := context.Background()

	// Prepare consultation data for email service
	consultationData := interfaces.ConsultationReminderData{
		BookingID:        booking.BookingID,
		UserName:         booking.UserName,
		ExpertName:       booking.ExpertName,
		ConsultationDate: booking.BookingTime.String(),
		ConsultationType: booking.ServiceType,
		ServiceTitle:     booking.ServiceTitle,
		ConsultationTime: booking.Duration.String(),
		MeetingLink:      booking.MeetingLink,
		Notes:            booking.Notes,
		ReminderType:     booking.ReminderType,
	}

	// Send reminder to user
	if err := rs.emailService.SendConsultationBookingRemindersToUser(ctx, booking.UserID, consultationData); err != nil {
		return fmt.Errorf("failed to send reminder to user %s: %w", booking.UserID, err)
	}

	// Send reminder to expert
	if err := rs.emailService.SendConsultationBookingRemindersToExpert(ctx, booking.ExpertID, consultationData); err != nil {
		return fmt.Errorf("failed to send reminder to expert %s: %w", booking.ExpertID, err)
	}

	// Update reminder status in database
	if err := rs.updateReminderStatus(booking.BookingID, booking.ReminderType); err != nil {
		log.Printf("⚠️ Failed to update reminder status for booking %s: %v", booking.BookingID, err)
		// Don't fail the entire operation if status update fails
	}

	return nil
}

func (rs *ReminderService) updateReminderStatus(bookingID, reminderType string) error {
	// Update the reminder status in the database
	// This prevents sending duplicate reminders
	var column string
	switch reminderType {
	case "1_day":
		column = "reminder_24h_sent"
	case "1_hour":
		column = "reminder_1h_sent"
	default:
		return fmt.Errorf("unknown reminder type: %s", reminderType)
	}

	query := fmt.Sprintf("UPDATE tbl_consultation_bookings SET %s = TRUE WHERE booking_id = ?", column)
	return rs.db.Exec(query, bookingID).Error
}

// CheckMissedBookings checks for bookings that were missed and updates their status
func (rs *ReminderService) CheckMissedBookings() error {
	log.Println("🔍 Checking for missed bookings...")

	// Update bookings that are past their time and still confirmed to "missed"
	query := `
		UPDATE tbl_consultation_bookings 
		SET consultation_status = 'missed',
			updated_at = NOW()
		WHERE consultation_status = 'confirmed'
		AND consultation_date_time < NOW() - INTERVAL '15 minutes'
	`

	result := rs.db.Exec(query)
	if result.Error != nil {
		return fmt.Errorf("failed to update missed bookings: %w", result.Error)
	}

	if result.RowsAffected > 0 {
		log.Printf("📋 Updated %d bookings to 'missed' status", result.RowsAffected)
	} else {
		log.Println("✅ No missed bookings found")
	}

	return nil
}

// HandleDuplicateBookings handles duplicate bookings for the same time slot
func (rs *ReminderService) HandleDuplicateBookings() error {
	log.Println("🔄 Checking for duplicate bookings...")

	// Find potential duplicate bookings (same expert, overlapping times)
	duplicates, err := rs.findDuplicateBookings()
	if err != nil {
		return fmt.Errorf("failed to find duplicate bookings: %w", err)
	}

	if len(duplicates) == 0 {
		log.Println("✅ No duplicate bookings found")
		return nil
	}

	log.Printf("📋 Found %d potential duplicate bookings", len(duplicates))

	// Handle each duplicate case
	for _, duplicate := range duplicates {
		if err := rs.handleDuplicateBooking(duplicate); err != nil {
			log.Printf("❌ Failed to handle duplicate booking %s: %v", duplicate.BookingID, err)
			continue
		}
	}

	log.Println("✅ Duplicate booking handling completed")
	return nil
}

type DuplicateBooking struct {
	BookingID   string    `json:"booking_id"`
	ExpertID    string    `json:"expert_id"`
	UserID      string    `json:"user_id"`
	BookingTime time.Time `json:"booking_time"`
	Status      string    `json:"status"`
	CreatedAt   time.Time `json:"created_at"`
}

func (rs *ReminderService) findDuplicateBookings() ([]DuplicateBooking, error) {
	var duplicates []DuplicateBooking

	// Find bookings that overlap in time for the same expert
	query := `
		SELECT 
			cb1.booking_id,
			cb1.expert_id,
			cb1.user_id,
			cb1.consultation_date_time as booking_time,
			cb1.consultation_status as status,
			cb1.created_at
		FROM tbl_consultation_bookings cb1
		JOIN tbl_consultation_bookings cb2 ON cb1.expert_id = cb2.expert_id
		WHERE cb1.booking_id != cb2.booking_id
		AND cb1.consultation_status IN ('confirmed', 'pending')
		AND cb2.consultation_status IN ('confirmed', 'pending')
		AND cb1.consultation_date_time = cb2.consultation_date_time
		AND cb1.created_at < cb2.created_at
		ORDER BY cb1.consultation_date_time ASC
	`

	err := rs.db.Raw(query).Scan(&duplicates).Error
	return duplicates, err
}

func (rs *ReminderService) handleDuplicateBooking(duplicate DuplicateBooking) error {
	// For now, we'll just log the duplicate and let manual intervention handle it
	// In a more sophisticated system, we might:
	// 1. Cancel the later booking
	// 2. Notify both users
	// 3. Suggest alternative times

	log.Printf("⚠️ Duplicate booking detected: %s for expert %s at %v",
		duplicate.BookingID, duplicate.ExpertID, duplicate.BookingTime)

	// You can implement auto-resolution logic here
	// For now, just mark it as needing manual review
	return rs.markBookingForReview(duplicate.BookingID, "duplicate_time_slot")
}

func (rs *ReminderService) markBookingForReview(bookingID, reason string) error {
	query := `
		UPDATE tbl_consultation_bookings 
		SET consultation_status = 'needs_review',
			consultation_notes = CONCAT(COALESCE(consultation_notes, ''), ' [AUTO-FLAGGED: ', ?, ']'),
			updated_at = NOW()
		WHERE booking_id = ?
	`

	return rs.db.Exec(query, reason, bookingID).Error
}

// GenerateWeeklyStatistics generates weekly booking statistics
func (rs *ReminderService) GenerateWeeklyStatistics() error {
	log.Println("📊 Generating weekly booking statistics...")

	stats, err := rs.getWeeklyStats()
	if err != nil {
		return fmt.Errorf("failed to get weekly statistics: %w", err)
	}

	log.Printf("📊 Weekly Stats: %+v", stats)

	// Here you could send this data to admin dashboard, email reports, etc.
	// For now, we'll just log it

	return nil
}

type WeeklyStats struct {
	TotalBookings     int `json:"total_bookings"`
	ConfirmedBookings int `json:"confirmed_bookings"`
	CancelledBookings int `json:"cancelled_bookings"`
	MissedBookings    int `json:"missed_bookings"`
	CompletedBookings int `json:"completed_bookings"`
}

func (rs *ReminderService) getWeeklyStats() (*WeeklyStats, error) {
	var stats WeeklyStats

	query := `
		SELECT 
			COUNT(*) as total_bookings,
			SUM(CASE WHEN consultation_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_bookings,
			SUM(CASE WHEN consultation_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_bookings,
			SUM(CASE WHEN consultation_status = 'missed' THEN 1 ELSE 0 END) as missed_bookings,
			SUM(CASE WHEN consultation_status = 'completed' THEN 1 ELSE 0 END) as completed_bookings
		FROM tbl_consultation_bookings
		WHERE created_at >= NOW() - INTERVAL '7 days'
	`

	err := rs.db.Raw(query).Scan(&stats).Error
	if err != nil {
		return nil, err
	}

	return &stats, nil
}
