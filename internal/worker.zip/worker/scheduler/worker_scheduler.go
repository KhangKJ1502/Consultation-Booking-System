// worker/scheduler/worker_scheduler.go
package scheduler

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/robfig/cron/v3"
	"gorm.io/gorm"

	"cbs_backend/internal/service/interfaces"
	"cbs_backend/internal/worker/booking"
	"cbs_backend/internal/worker/notification/sender"
)

// =====================================================================
// CONSTANTS AND CONFIGURATION
// =====================================================================

const (
	DefaultQueueSize          = 1000
	DefaultMaxWorkers         = 10
	NotificationCheckInterval = 5 * time.Second
	MaxQueueFullness          = 2
	TestStartupDelay          = 5 * time.Second
	JobTimeout                = 30 * time.Minute
	RetryBackoffMultiplier    = 2
	MaxRetryDelay             = 10 * time.Minute
)

// =====================================================================
// INTERFACES
// =====================================================================

// Service defines the interface for worker services
type Service interface {
	ProcessJob(ctx context.Context, job Job) error
	GetServiceName() string
}

// =====================================================================
// WORKER SCHEDULER STRUCT
// =====================================================================

type WorkerScheduler struct {
	// Core components
	db     *gorm.DB
	redis  *redis.Client
	cron   *cron.Cron
	ctx    context.Context
	cancel context.CancelFunc
	wg     sync.WaitGroup

	// Job processing
	jobQueue   chan Job
	maxWorkers int
	activeJobs int
	jobMutex   sync.RWMutex

	// Services
	emailService        interfaces.EmailService
	bookingService      *booking.ReminderService
	notificationService *sender.NotificationService
	jobProcessor        *JobProcessor

	// Configuration
	config *Config
}

// Config holds configuration for the worker scheduler
type Config struct {
	MaxWorkers             int
	QueueSize              int
	NotificationInterval   time.Duration
	JobTimeout             time.Duration
	RetryBackoffMultiplier int
	MaxRetryDelay          time.Duration
}

// DefaultConfig returns default configuration
func DefaultConfig() *Config {
	return &Config{
		MaxWorkers:             DefaultMaxWorkers,
		QueueSize:              DefaultQueueSize,
		NotificationInterval:   NotificationCheckInterval,
		JobTimeout:             JobTimeout,
		RetryBackoffMultiplier: RetryBackoffMultiplier,
		MaxRetryDelay:          MaxRetryDelay,
	}
}

// =====================================================================
// CONSTRUCTOR
// =====================================================================

// NewWorkerScheduler creates a new worker scheduler instance
func NewWorkerScheduler(db *gorm.DB, redisClient *redis.Client, emailService interfaces.EmailService, config *Config) *WorkerScheduler {
	if config == nil {
		config = DefaultConfig()
	}

	ctx, cancel := context.WithCancel(context.Background())

	// Configure cron parser with all time fields
	parser := cron.NewParser(cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow | cron.Descriptor)
	cronScheduler := cron.New(
		cron.WithParser(parser),
		cron.WithChain(
			cron.Recover(cron.DefaultLogger),
			cron.DelayIfStillRunning(cron.DefaultLogger),
		),
	)

	ws := &WorkerScheduler{
		// Core components
		db:         db,
		redis:      redisClient,
		cron:       cronScheduler,
		ctx:        ctx,
		cancel:     cancel,
		jobQueue:   make(chan Job, config.QueueSize),
		maxWorkers: config.MaxWorkers,
		config:     config,

		// Services
		emailService: emailService,
	}

	// Initialize services
	ws.initializeServices()

	return ws
}

// initializeServices initializes all required services
func (ws *WorkerScheduler) initializeServices() {
	// Initialize booking service
	ws.bookingService = booking.NewReminderService(ws.db, ws.emailService)

	// Initialize notification service
	ws.notificationService = sender.NewNotificationService(ws.db, ws.redis, ws.emailService)

	// Initialize job processor
	ws.jobProcessor = NewJobProcessor(ws)
}

// =====================================================================
// LIFECYCLE MANAGEMENT
// =====================================================================

// Start starts the worker scheduler
func (ws *WorkerScheduler) Start() error {
	log.Println("🚀 Starting Worker Scheduler...")

	// Start worker goroutines
	if err := ws.startWorkers(); err != nil {
		return fmt.Errorf("failed to start workers: %w", err)
	}

	// Start notification processor
	go ws.startNotificationProcessor()

	// Schedule all cron jobs
	if err := ws.scheduleCronJobs(); err != nil {
		return fmt.Errorf("failed to schedule cron jobs: %w", err)
	}

	// Start cron scheduler
	ws.cron.Start()

	// Log startup information
	ws.logStartupInfo()

	// Schedule test job after startup delay
	ws.scheduleTestJob()

	log.Printf("✅ Worker Scheduler started successfully with %d workers", ws.maxWorkers)
	return nil
}

// Stop gracefully stops the worker scheduler
func (ws *WorkerScheduler) Stop() {
	log.Println("🛑 Stopping Worker Scheduler...")

	// Stop cron scheduler and wait for completion
	cronCtx := ws.cron.Stop()

	// Wait for cron jobs to complete with timeout
	select {
	case <-cronCtx.Done():
		log.Println("✅ Cron scheduler stopped")
	case <-time.After(30 * time.Second):
		log.Println("⚠️ Cron scheduler stop timeout")
	}

	// Signal all goroutines to stop
	ws.cancel()

	// Close job queue to signal workers
	close(ws.jobQueue)

	// Wait for all workers to finish with timeout
	done := make(chan struct{})
	go func() {
		ws.wg.Wait()
		close(done)
	}()

	select {
	case <-done:
		log.Println("✅ All workers stopped")
	case <-time.After(60 * time.Second):
		log.Println("⚠️ Worker shutdown timeout")
	}

	log.Println("✅ Worker Scheduler stopped")
}

// =====================================================================
// WORKER MANAGEMENT
// =====================================================================

// startWorkers starts the worker goroutines
func (ws *WorkerScheduler) startWorkers() error {
	log.Printf("👷 Starting %d workers...", ws.maxWorkers)

	for i := 0; i < ws.maxWorkers; i++ {
		ws.wg.Add(1)
		go ws.worker(i)
	}

	log.Printf("✅ Started %d workers", ws.maxWorkers)
	return nil
}

// worker is the main worker goroutine that processes jobs from the queue
func (ws *WorkerScheduler) worker(id int) {
	defer ws.wg.Done()
	log.Printf("👷 Worker %d started", id)

	for {
		select {
		case job, ok := <-ws.jobQueue:
			if !ok {
				log.Printf("👷 Worker %d stopped - queue closed", id)
				return
			}
			ws.handleJob(job, id)

		case <-ws.ctx.Done():
			log.Printf("👷 Worker %d stopped by context", id)
			return
		}
	}
}

// handleJob processes a single job
func (ws *WorkerScheduler) handleJob(job Job, workerID int) {
	// Update active job count
	ws.updateActiveJobs(1)
	defer ws.updateActiveJobs(-1)

	// Create job context with timeout
	jobCtx, cancel := context.WithTimeout(ws.ctx, ws.config.JobTimeout)
	defer cancel()

	// Process the job
	ws.processJob(jobCtx, job, workerID)
}

// updateActiveJobs safely updates the active job count
func (ws *WorkerScheduler) updateActiveJobs(delta int) {
	ws.jobMutex.Lock()
	defer ws.jobMutex.Unlock()
	ws.activeJobs += delta
}

// =====================================================================
// JOB PROCESSING
// =====================================================================

// processJob processes a single job with error handling and retry logic
func (ws *WorkerScheduler) processJob(ctx context.Context, job Job, workerID int) {
	log.Printf("⚙️ Worker %d processing job: %s (type: %s)", workerID, job.ID, job.Type)

	// Record job start
	if err := ws.recordJobStart(job); err != nil {
		log.Printf("⚠️ Failed to record job start: %v", err)
	}

	// Execute job with timeout
	startTime := time.Now()
	err := ws.jobProcessor.ExecuteJob(ctx, job)
	duration := time.Since(startTime)

	// Handle job result
	ws.handleJobResult(job, err, duration)
}

// handleJobResult handles the result of job execution
func (ws *WorkerScheduler) handleJobResult(job Job, err error, duration time.Duration) {
	if err != nil {
		ws.handleJobFailure(job, err, duration)
	} else {
		ws.handleJobSuccess(job, duration)
	}
}

// handleJobSuccess handles successful job completion
func (ws *WorkerScheduler) handleJobSuccess(job Job, duration time.Duration) {
	log.Printf("✅ Job %s completed successfully in %v", job.ID, duration)

	if err := ws.recordJobSuccess(job, duration); err != nil {
		log.Printf("⚠️ Failed to record job success: %v", err)
	}
}

// handleJobFailure handles job failure with retry logic
func (ws *WorkerScheduler) handleJobFailure(job Job, err error, duration time.Duration) {
	log.Printf("❌ Job %s failed after %v: %v", job.ID, duration, err)

	// Record failure
	if recordErr := ws.recordJobFailure(job, err, duration); recordErr != nil {
		log.Printf("⚠️ Failed to record job failure: %v", recordErr)
	}

	// Retry if possible
	if job.RetryCount < job.MaxRetries {
		ws.scheduleRetry(job)
	} else {
		log.Printf("💀 Job %s failed permanently after %d attempts", job.ID, job.MaxRetries)
		ws.handleJobPermanentFailure(job, err)
	}
}

// scheduleRetry schedules a job for retry with exponential backoff
func (ws *WorkerScheduler) scheduleRetry(job Job) {
	job.RetryCount++

	// Calculate retry delay with exponential backoff
	baseDelay := time.Duration(job.RetryCount*job.RetryCount) * time.Minute
	retryDelay := baseDelay
	if retryDelay > ws.config.MaxRetryDelay {
		retryDelay = ws.config.MaxRetryDelay
	}

	job.ScheduledAt = time.Now().Add(retryDelay)

	log.Printf("🔄 Retrying job %s in %v (attempt %d/%d)",
		job.ID, retryDelay, job.RetryCount, job.MaxRetries)

	// Schedule retry
	go func() {
		time.Sleep(retryDelay)
		ws.AddJob(job)
	}()
}

// handleJobPermanentFailure handles jobs that have failed permanently
func (ws *WorkerScheduler) handleJobPermanentFailure(job Job, err error) {
	// Log permanent failure
	log.Printf("💀 Job %s permanently failed: %v", job.ID, err)

	// Here you could implement additional handling like:
	// - Sending alerts
	// - Moving to dead letter queue
	// - Notifying administrators
}

// =====================================================================
// JOB QUEUE MANAGEMENT
// =====================================================================

// AddJob adds a job to the processing queue
func (ws *WorkerScheduler) AddJob(job Job) {
	// Check if scheduler is shutting down
	select {
	case <-ws.ctx.Done():
		log.Printf("⚠️ Cannot add job %s: scheduler is shutting down", job.ID)
		return
	default:
	}

	// Set job timestamps
	if job.CreatedAt.IsZero() {
		job.CreatedAt = time.Now()
	}
	job.UpdatedAt = time.Now()

	// Generate ID if not set
	if job.ID == "" {
		job.ID = generateJobID()
	}

	// Check queue capacity
	if ws.isQueueFull() {
		log.Printf("⚠️ Queue is full, dropping job: %s", job.ID)
		return
	}

	// Add job to queue
	select {
	case ws.jobQueue <- job:
		log.Printf("📝 Job added to queue: %s (type: %s)", job.ID, job.Type)
	case <-ws.ctx.Done():
		log.Printf("⚠️ Cannot add job %s: scheduler is shutting down", job.ID)
	default:
		log.Printf("⚠️ Queue is full, dropping job: %s", job.ID)
	}
}

// isQueueFull checks if the job queue is at capacity
func (ws *WorkerScheduler) isQueueFull() bool {
	ws.jobMutex.RLock()
	defer ws.jobMutex.RUnlock()
	return len(ws.jobQueue) >= cap(ws.jobQueue) || ws.activeJobs >= ws.maxWorkers*MaxQueueFullness
}

// =====================================================================
// CRON JOB SCHEDULING
// =====================================================================

// scheduleCronJobs schedules all recurring jobs
func (ws *WorkerScheduler) scheduleCronJobs() error {
	log.Println("📅 Scheduling cron jobs...")

	cronJobs := []struct {
		name     string
		schedule string
		jobType  string
		payload  interface{}
		priority int
		retries  int
	}{
		{
			name:     "process_notifications",
			schedule: "* * * * *", // Every minute
			jobType:  JobTypeProcessNotifications,
			payload:  nil,
			priority: 1,
			retries:  3,
		},
		{
			name:     "booking_reminder",
			schedule: "*/2 * * * *", // Every 2 minutes
			jobType:  JobTypeBookingReminder,
			payload:  nil,
			priority: 1,
			retries:  3,
		},
		{
			name:     "check_missed_bookings",
			schedule: "*/15 * * * *", // Every 15 minutes
			jobType:  JobTypeCheckMissedBookings,
			payload:  nil,
			priority: 2,
			retries:  3,
		},
		{
			name:     "handle_duplicate_bookings",
			schedule: "*/30 * * * *", // Every 30 minutes
			jobType:  JobTypeHandleDuplicateBookings,
			payload:  nil,
			priority: 2,
			retries:  3,
		},
		{
			name:     "cleanup_old_data",
			schedule: "0 2 * * *", // Daily at 2 AM
			jobType:  JobTypeCleanupOldData,
			payload:  map[string]interface{}{"days": 30},
			priority: 3,
			retries:  2,
		},
		{
			name:     "weekly_statistics",
			schedule: "0 6 * * 0", // Weekly on Sunday at 6 AM
			jobType:  JobTypeWeeklyStatistics,
			payload:  nil,
			priority: 2,
			retries:  3,
		},
	}

	for _, cronJob := range cronJobs {
		if err := ws.scheduleCronJob(cronJob); err != nil {
			return fmt.Errorf("failed to schedule %s: %w", cronJob.name, err)
		}
	}

	log.Println("📅 All cron jobs scheduled successfully")
	return nil
}

// scheduleCronJob schedules a single cron job
func (ws *WorkerScheduler) scheduleCronJob(cronJob struct {
	name     string
	schedule string
	jobType  string
	payload  interface{}
	priority int
	retries  int
}) error {
	entryID, err := ws.cron.AddFunc(cronJob.schedule, func() {
		log.Printf("⏰ Cron triggered: %s", cronJob.name)

		job := Job{
			ID:         generateJobID(),
			Type:       cronJob.jobType,
			Payload:    cronJob.payload,
			Priority:   cronJob.priority,
			MaxRetries: cronJob.retries,
			CreatedAt:  time.Now(),
			UpdatedAt:  time.Now(),
		}

		ws.AddJob(job)
	})

	if err != nil {
		return fmt.Errorf("failed to add cron job: %w", err)
	}

	log.Printf("✅ Scheduled %s (ID: %d) - %s", cronJob.name, entryID, cronJob.schedule)
	return nil
}

// scheduleTestJob schedules a test job after startup
func (ws *WorkerScheduler) scheduleTestJob() {
	go func() {
		time.Sleep(TestStartupDelay)
		log.Println("⏰ Manual trigger: booking_reminder (test)")

		testJob := Job{
			ID:         generateJobID(),
			Type:       JobTypeBookingReminder,
			Payload:    nil,
			Priority:   1,
			MaxRetries: 3,
			CreatedAt:  time.Now(),
			UpdatedAt:  time.Now(),
		}

		ws.AddJob(testJob)
	}()
}

// =====================================================================
// NOTIFICATION PROCESSING
// =====================================================================

// startNotificationProcessor starts the notification processor goroutine
func (ws *WorkerScheduler) startNotificationProcessor() {
	log.Println("📧 Starting notification processor...")

	ticker := time.NewTicker(ws.config.NotificationInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			if err := ws.processNotifications(); err != nil {
				log.Printf("⚠️ Failed to process notifications: %v", err)
			}
		case <-ws.ctx.Done():
			log.Println("🛑 Notification processor stopped")
			return
		}
	}
}

// processNotifications processes pending notifications
func (ws *WorkerScheduler) processNotifications() error {
	notifications, err := ws.fetchPendingNotifications()
	if err != nil {
		return fmt.Errorf("failed to get pending notifications: %w", err)
	}

	if len(notifications) > 0 {
		log.Printf("📧 Found %d pending notifications", len(notifications))

		for _, notification := range notifications {
			if err := ws.processNotification(notification); err != nil {
				log.Printf("⚠️ Failed to process notification %s: %v", notification.NotificationID, err)
			}
		}
	}

	return nil
}

// =====================================================================
// UTILITY FUNCTIONS
// =====================================================================

// logStartupInfo logs startup information
func (ws *WorkerScheduler) logStartupInfo() {
	entries := ws.cron.Entries()
	log.Printf("📋 Total cron entries: %d", len(entries))

	for i, entry := range entries {
		log.Printf("  Entry %d: Next run at %v", i+1, entry.Next)
	}
}

// GetStats returns scheduler statistics
func (ws *WorkerScheduler) GetStats() map[string]interface{} {
	ws.jobMutex.RLock()
	defer ws.jobMutex.RUnlock()

	return map[string]interface{}{
		"active_jobs":    ws.activeJobs,
		"max_workers":    ws.maxWorkers,
		"queue_length":   len(ws.jobQueue),
		"queue_capacity": cap(ws.jobQueue),
		"cron_entries":   len(ws.cron.Entries()),
		"status":         "running",
	}
}

// GetHealthStatus returns health status of the scheduler
func (ws *WorkerScheduler) GetHealthStatus() map[string]interface{} {
	ws.jobMutex.RLock()
	defer ws.jobMutex.RUnlock()

	isHealthy := true
	issues := []string{}

	// Check if queue is too full
	queueUsage := float64(len(ws.jobQueue)) / float64(cap(ws.jobQueue))
	if queueUsage > 0.8 {
		isHealthy = false
		issues = append(issues, "Queue is over 80% full")
	}

	// Check if too many jobs are active
	if ws.activeJobs > ws.maxWorkers {
		isHealthy = false
		issues = append(issues, "More active jobs than workers")
	}

	status := "healthy"
	if !isHealthy {
		status = "unhealthy"
	}

	return map[string]interface{}{
		"status":       status,
		"healthy":      isHealthy,
		"issues":       issues,
		"queue_usage":  queueUsage,
		"active_jobs":  ws.activeJobs,
		"max_workers":  ws.maxWorkers,
		"cron_running": ws.cron != nil,
	}
}

// =====================================================================
// DATABASE OPERATIONS
// =====================================================================

// recordJobStart records the start of a job
func (ws *WorkerScheduler) recordJobStart(job Job) error {
	// Implementation depends on your job tracking requirements
	// This is a placeholder for job tracking in database
	return nil
}

// recordJobSuccess records successful job completion
func (ws *WorkerScheduler) recordJobSuccess(job Job, duration time.Duration) error {
	// Implementation depends on your job tracking requirements
	// This is a placeholder for job tracking in database
	return nil
}

// recordJobFailure records job failure
func (ws *WorkerScheduler) recordJobFailure(job Job, err error, duration time.Duration) error {
	// Implementation depends on your job tracking requirements
	// This is a placeholder for job tracking in database
	return nil
}

// fetchPendingNotifications fetches pending notifications from database
func (ws *WorkerScheduler) fetchPendingNotifications() ([]PendingNotification, error) {
	var notifications []PendingNotification

	query := `
		SELECT 
			sn.notification_id,
			sn.recipient_user_id as user_id,
			u.user_email,
			sn.notification_title as title,
			sn.notification_message as message,
			sn.notification_data as data
		FROM tbl_system_notifications sn
		JOIN tbl_users u ON sn.recipient_user_id = u.user_id
		WHERE sn.notification_status = 'pending'
		AND 'email' = ANY(sn.delivery_methods)
		AND sn.notification_created_at >= NOW() - INTERVAL '1 hour'
		ORDER BY sn.notification_created_at ASC
		LIMIT 50
	`

	err := ws.db.Raw(query).Scan(&notifications).Error
	return notifications, err
}

// processNotification processes a single notification
func (ws *WorkerScheduler) processNotification(notification PendingNotification) error {
	// Update status to processing
	if err := ws.updateNotificationStatus(notification.NotificationID, "processing"); err != nil {
		return fmt.Errorf("failed to update notification status: %w", err)
	}

	// Create email job
	job := Job{
		ID:   generateJobID(),
		Type: JobTypeSendEmail,
		Payload: map[string]interface{}{
			"notification_id": notification.NotificationID,
			"user_id":         notification.UserID,
			"recipient":       notification.UserEmail,
			"subject":         notification.Title,
			"body":            notification.Message,
			"data":            notification.Data,
			"template":        "notification",
		},
		Priority:   1,
		MaxRetries: 3,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}

	// Add job to queue
	ws.AddJob(job)

	log.Printf("➕ Added email job for notification %s", notification.NotificationID)
	return nil
}

// updateNotificationStatus updates the status of a notification
func (ws *WorkerScheduler) updateNotificationStatus(notificationID, status string) error {
	return ws.db.Exec(
		"UPDATE tbl_system_notifications SET notification_status = ?, updated_at = NOW() WHERE notification_id = ?",
		status, notificationID,
	).Error
}

// generateJobID generates a unique job ID
func generateJobID() string {
	return fmt.Sprintf("job_%d", time.Now().UnixNano())
}
