// worker/scheduler/job_processor.go
package scheduler

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"cbs_backend/internal/service/interfaces"
)

// =====================================================================
// JOB TYPE CONSTANTS
// =====================================================================

const (
	JobTypeSendEmail                = "send_email"
	JobTypeSendTelegram             = "send_telegram"
	JobTypeSendSMS                  = "send_sms"
	JobTypeBookingReminder          = "booking_reminder"
	JobTypeCheckMissedBookings      = "check_missed_bookings"
	JobTypeHandleDuplicateBookings  = "handle_duplicate_bookings"
	JobTypeCleanupOldData           = "cleanup_old_data"
	JobTypeWeeklyStatistics         = "weekly_statistics"
	JobTypeSendEmailBatch           = "send_email_batch"
	JobTypeProcessNotifications     = "process_notifications"
)

// =====================================================================
// JOB STRUCT
// =====================================================================

// Job represents a job to be processed
type Job struct {
	ID          string      `json:"id"`
	Type        string      `json:"type"`
	Payload     interface{} `json:"payload"`
	Priority    int         `json:"priority"`
	MaxRetries  int         `json:"max_retries"`
	RetryCount  int         `json:"retry_count"`
	CreatedAt   time.Time   `json:"created_at"`
	UpdatedAt   time.Time   `json:"updated_at"`
	ScheduledAt time.Time   `json:"scheduled_at"`
}

// =====================================================================
// NOTIFICATION STRUCTS
// =====================================================================

// PendingNotification represents a notification that needs to be processed
type PendingNotification struct {
	NotificationID string `json:"notification_id"`
	UserID         string `json:"user_id"`
	UserEmail      string `json:"user_email"`
	Title          string `json:"title"`
	Message        string `json:"message"`
	Data           string `json:"data"`
}

// =====================================================================
// PAYLOAD STRUCTS
// =====================================================================

// EmailJobPayload represents the payload for email jobs
type EmailJobPayload struct {
	UserID                 string                                            `json:"user_id"`
	Email                  string                                            `json:"email"`
	EmailType              string                                            `json:"email_type"`
	Subject                string                                            `json:"subject,omitempty"`
	Body                   string                                            `json:"body,omitempty"`
	Template               string                                            `json:"template,omitempty"`
	FullName               string                                            `json:"full_name,omitempty"`
	VerificationToken      string                                            `json:"verification_token,omitempty"`
	ResetToken             string                                            `json:"reset_token,omitempty"`
	ConsultationData       *interfaces.ConsultationBookingData               `json:"consultation_data,omitempty"`
	CancellationDataUser   *interfaces.ConsultationCancellationDataForUser   `json:"cancellation_data_user,omitempty"`
	CancellationDataExpert *interfaces.ConsultationCancellationDataForExpert `json:"cancellation_data_expert,omitempty"`
	ReminderData           *interfaces.ConsultationReminderData              `json:"reminder_data,omitempty"`
	Data                   map[string]interface{}                            `json:"data,omitempty"`
}

// BookingJobPayload represents the payload for booking jobs
type BookingJobPayload struct {
	BookingID   string                 `json:"booking_id"`
	UserID      string                 `json:"user_id"`
	ExpertID    string                 `json:"expert_id"`
	BookingTime time.Time              `json:"booking_time"`
	JobType     string                 `json:"job_type"`
	Data        map[string]interface{} `json:"data"`
}

// NotificationJobPayload represents the payload for notification jobs
type NotificationJobPayload struct {
	NotificationID   string                 `json:"notification_id,omitempty"`
	RecipientID      string                 `json:"recipient_id"`
	RecipientEmail   string                 `json:"recipient_email,omitempty"`
	NotificationType string                 `json:"notification_type"`
	Channel          string                 `json:"channel"` // email, sms, telegram
	Message          string                 `json:"message"`
	Subject          string                 `json:"subject,omitempty"`
	Template         string                 `json:"template,omitempty"`
	Data             map[string]interface{} `json:"data"`
}

// CleanupJobPayload represents the payload for cleanup jobs
type CleanupJobPayload struct {
	TableName   string    `json:"table_name"`
	Days        int       `json:"days"`
	OlderThan   time.Time `json:"older_than"`
	BatchSize   int       `json:"batch_size"`
	ArchiveData bool      `json:"archive_data"`
}

// StatisticsJobPayload represents the payload for statistics jobs
type StatisticsJobPayload struct {
	ReportType string                 `json:"report_type"`
	Period     string                 `json:"period"`
	StartDate  time.Time              `json:"start_date"`
	EndDate    time.Time              `json:"end_date"`
	Recipients []string               `json:"recipients"`
	Data       map[string]interface{} `json:"data"`
}

// =====================================================================
// EMAIL TYPE CONSTANTS
// =====================================================================

const (