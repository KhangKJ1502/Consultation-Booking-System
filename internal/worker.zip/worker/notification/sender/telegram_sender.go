// =====================================================================
// TELEGRAM SENDER
// =====================================================================

// worker/notification/sender/telegram_sender.go
package sender

import (
	"fmt"
	"log"
	"time"

	"gorm.io/gorm"
)

type TelegramSender struct {
	db *gorm.DB
}

func NewTelegramSender(db *gorm.DB) *TelegramSender {
	return &TelegramSender{
		db: db,
	}
}

// TelegramJobPayload represents the payload for Telegram jobs
type TelegramJobPayload struct {
	NotificationID string                 `json:"notification_id,omitempty"`
	UserID         string                 `json:"user_id"`
	ChatID         string                 `json:"chat_id"`
	Message        string                 `json:"message"`
	Data           map[string]interface{} `json:"data"`
}

// SendTelegram processes a Telegram job
func (ts *TelegramSender) SendTelegram(payload TelegramJobPayload) error {
	log.Printf("📞 Processing Telegram job for user %s (chat: %s)", payload.UserID, payload.ChatID)

	// Validate payload
	if err := ts.validateTelegramPayload(payload); err != nil {
		return fmt.Errorf("invalid Telegram payload: %w", err)
	}

	// Here you would integrate with Telegram Bot API
	// For now, we'll simulate the Telegram sending
	if err := ts.sendTelegramMessage(payload); err != nil {
		log.Printf("❌ Failed to send Telegram message: %v", err)

		// Update notification status to failed if notification_id exists
		if payload.NotificationID != "" {
			ts.updateNotificationStatus(payload.NotificationID, "failed", err.Error())
		}
		return err
	}

	log.Printf("✅ Telegram message sent successfully to %s", payload.ChatID)

	// Update notification status to sent if notification_id exists
	if payload.NotificationID != "" {
		ts.updateNotificationStatus(payload.NotificationID, "sent", "")
	}

	return nil
}

func (ts *TelegramSender) validateTelegramPayload(payload TelegramJobPayload) error {
	if payload.UserID == "" {
		return fmt.Errorf("user_id is required")
	}

	if payload.ChatID == "" {
		return fmt.Errorf("chat_id is required")
	}

	if payload.Message == "" {
		return fmt.Errorf("message is required")
	}

	return nil
}

func (ts *TelegramSender) sendTelegramMessage(payload TelegramJobPayload) error {
	// TODO: Implement actual Telegram Bot API integration
	// Example:
	// - Use telegram-bot-api library: https://github.com/go-telegram-bot-api/telegram-bot-api
	// - Or use tgbotapi: https://github.com/Syfaro/telegram-bot-api

	log.Printf("📞 [SIMULATED] Sending Telegram message to %s: %s", payload.ChatID, payload.Message)

	// Simulate processing time
	time.Sleep(300 * time.Millisecond)

	// For demonstration, we'll just log the message
	// In production, replace this with actual Telegram Bot API call

	return nil
}

func (ts *TelegramSender) updateNotificationStatus(notificationID, status, errorMsg string) error {
	query := `
		UPDATE tbl_system_notifications 
		SET notification_status = ?, 
			notification_error = ?,
			notification_sent_at = CASE WHEN ? = 'sent' THEN NOW() ELSE notification_sent_at END,
			updated_at = NOW()
		WHERE notification_id = ?
	`

	return ts.db.Exec(query, status, errorMsg, status, notificationID).Error
}

// =====================================================================
// HELPER FUNCTIONS AND TYPES
// =====================================================================

// MessageTemplate represents a message template
type MessageTemplate struct {
	ID        string            `json:"id"`
	Name      string            `json:"name"`
	Template  string            `json:"template"`
	Variables map[string]string `json:"variables"`
}

// FormatMessage formats a message using template and data
func FormatMessage(template string, data map[string]interface{}) string {
	message := template

	// Simple template replacement
	// In production, you might want to use a more sophisticated templating engine
	for key, value := range data {
		placeholder := fmt.Sprintf("{{%s}}", key)
		if strValue, ok := value.(string); ok {
			message = replaceAll(message, placeholder, strValue)
		}
	}

	return message
}

func replaceAll(s, old, new string) string {
	// Simple string replacement
	// In production, you might want to use regex or more sophisticated replacement
	result := s
	for {
		if newResult := replace(result, old, new); newResult == result {
			break
		} else {
			result = newResult
		}
	}
	return result
}

func replace(s, old, new string) string {
	// Basic string replacement function
	if old == "" {
		return s
	}

	var result []rune
	source := []rune(s)
	oldRunes := []rune(old)
	newRunes := []rune(new)

	for i := 0; i < len(source); {
		if i+len(oldRunes) <= len(source) {
			match := true
			for j := 0; j < len(oldRunes); j++ {
				if source[i+j] != oldRunes[j] {
					match = false
					break
				}
			}

			if match {
				result = append(result, newRunes...)
				i += len(oldRunes)
				continue
			}
		}

		result = append(result, source[i])
		i++
	}

	return string(result)
}
