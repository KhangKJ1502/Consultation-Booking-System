// worker/notification/sender/sms_sender.go
package sender

import (
	"fmt"
	"log"
	"time"

	"gorm.io/gorm"
)

type SMSSender struct {
	db *gorm.DB
}

func NewSMSSender(db *gorm.DB) *SMSSender {
	return &SMSSender{
		db: db,
	}
}

// SMSJobPayload represents the payload for SMS jobs
type SMSJobPayload struct {
	NotificationID string                 `json:"notification_id,omitempty"`
	UserID         string                 `json:"user_id"`
	PhoneNumber    string                 `json:"phone_number"`
	Message        string                 `json:"message"`
	Data           map[string]interface{} `json:"data"`
}

// SendSMS processes an SMS job
func (ss *SMSSender) SendSMS(payload SMSJobPayload) error {
	log.Printf("📱 Processing SMS job for user %s (phone: %s)", payload.UserID, payload.PhoneNumber)

	// Validate payload
	if err := ss.validateSMSPayload(payload); err != nil {
		return fmt.Errorf("invalid SMS payload: %w", err)
	}

	// Here you would integrate with your SMS provider (Twilio, AWS SNS, etc.)
	// For now, we'll simulate the SMS sending
	if err := ss.sendSMSMessage(payload); err != nil {
		log.Printf("❌ Failed to send SMS: %v", err)

		// Update notification status to failed if notification_id exists
		if payload.NotificationID != "" {
			ss.updateNotificationStatus(payload.NotificationID, "failed", err.Error())
		}
		return err
	}

	log.Printf("✅ SMS sent successfully to %s", payload.PhoneNumber)

	// Update notification status to sent if notification_id exists
	if payload.NotificationID != "" {
		ss.updateNotificationStatus(payload.NotificationID, "sent", "")
	}

	return nil
}

func (ss *SMSSender) validateSMSPayload(payload SMSJobPayload) error {
	if payload.UserID == "" {
		return fmt.Errorf("user_id is required")
	}

	if payload.PhoneNumber == "" {
		return fmt.Errorf("phone_number is required")
	}

	if payload.Message == "" {
		return fmt.Errorf("message is required")
	}

	// Validate phone number format (basic validation)
	if len(payload.PhoneNumber) < 10 {
		return fmt.Errorf("invalid phone number format")
	}

	return nil
}

func (ss *SMSSender) sendSMSMessage(payload SMSJobPayload) error {
	// TODO: Implement actual SMS sending logic
	// Example integrations:
	// - Twilio: https://github.com/twilio/twilio-go
	// - AWS SNS: https://docs.aws.amazon.com/sns/latest/dg/sms_publish-to-phone.html
	// - Firebase Cloud Messaging

	log.Printf("📱 [SIMULATED] Sending SMS to %s: %s", payload.PhoneNumber, payload.Message)

	// Simulate processing time
	time.Sleep(500 * time.Millisecond)

	// For demonstration, we'll just log the SMS
	// In production, replace this with actual SMS API call

	return nil
}

func (ss *SMSSender) updateNotificationStatus(notificationID, status, errorMsg string) error {
	query := `
		UPDATE tbl_system_notifications 
		SET notification_status = ?, 
			notification_error = ?,
			notification_sent_at = CASE WHEN ? = 'sent' THEN NOW() ELSE notification_sent_at END,
			updated_at = NOW()
		WHERE notification_id = ?
	`

	return ss.db.Exec(query, status, errorMsg, status, notificationID).Error
}
