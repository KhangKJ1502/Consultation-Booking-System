// worker/notification/notification_service.go
package sender

import (
	"cbs_backend/internal/service/interfaces"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/redis/go-redis/v9"
	"gorm.io/gorm"
)

type NotificationService struct {
	db           *gorm.DB
	redisClient  *redis.Client
	emailService interfaces.EmailService

	// Senders
	emailSender    *EmailSender
	smsSender      *SMSSender
	telegramSender *TelegramSender
}

func NewNotificationService(db *gorm.DB, redisClient *redis.Client, emailService interfaces.EmailService) *NotificationService {
	return &NotificationService{
		db:             db,
		redisClient:    redisClient,
		emailService:   emailService,
		emailSender:    NewEmailSender(db, emailService),
		smsSender:      NewSMSSender(db),
		telegramSender: NewTelegramSender(db),
	}
}

// NotificationData represents notification information
type NotificationData struct {
	NotificationID  string                 `json:"notification_id"`
	UserID          string                 `json:"user_id"`
	UserEmail       string                 `json:"user_email"`
	UserPhone       string                 `json:"user_phone"`
	TelegramChatID  string                 `json:"telegram_chat_id"`
	Title           string                 `json:"title"`
	Message         string                 `json:"message"`
	Data            map[string]interface{} `json:"data"`
	Type            string                 `json:"type"`
	DeliveryMethods []string               `json:"delivery_methods"`
	CreatedAt       time.Time              `json:"created_at"`
	Priority        int                    `json:"priority"`
	Template        string                 `json:"template"`
}

// ProcessNotificationJob processes a notification job based on its type
func (ns *NotificationService) ProcessNotificationJob(jobType string, payload interface{}) error {
	log.Printf("📬 Processing notification job: %s", jobType)

	switch jobType {
	case "send_email":
		return ns.processEmailJob(payload)
	case "send_sms":
		return ns.processSMSJob(payload)
	case "send_telegram":
		return ns.processTelegramJob(payload)
	case "send_email_batch":
		return ns.processEmailBatchJob(payload)
	default:
		return fmt.Errorf("unknown notification job type: %s", jobType)
	}
}

func (ns *NotificationService) processEmailJob(payload interface{}) error {
	emailPayload, err := ns.parseEmailJobPayload(payload)
	if err != nil {
		return fmt.Errorf("failed to parse email payload: %w", err)
	}

	return ns.emailSender.SendEmail(emailPayload)
}

func (ns *NotificationService) processSMSJob(payload interface{}) error {
	smsPayload, err := ns.parseSMSJobPayload(payload)
	if err != nil {
		return fmt.Errorf("failed to parse SMS payload: %w", err)
	}

	return ns.smsSender.SendSMS(smsPayload)
}

func (ns *NotificationService) processTelegramJob(payload interface{}) error {
	telegramPayload, err := ns.parseTelegramJobPayload(payload)
	if err != nil {
		return fmt.Errorf("failed to parse Telegram payload: %w", err)
	}

	return ns.telegramSender.SendTelegram(telegramPayload)
}

func (ns *NotificationService) processEmailBatchJob(payload interface{}) error {
	return ns.emailSender.ProcessEmailBatch(payload)
}

// GetPendingNotifications retrieves notifications that need to be processed
func (ns *NotificationService) GetPendingNotifications() ([]NotificationData, error) {
	var notifications []NotificationData

	query := `
        SELECT 
            sn.notification_id,
            sn.recipient_user_id as user_id,
            u.user_email,
            u.user_phone,
            u.telegram_chat_id,
            sn.notification_title as title,
            sn.notification_message as message,
            sn.notification_data as data,
            sn.notification_type as type,
            sn.delivery_methods,
            sn.notification_created_at as created_at,
            sn.notification_priority as priority,
            sn.notification_template as template
        FROM tbl_system_notifications sn
        JOIN tbl_users u ON sn.recipient_user_id = u.user_id
        WHERE sn.notification_status = 'pending'
        AND sn.notification_created_at >= NOW() - INTERVAL '1 hour'
        ORDER BY sn.notification_priority ASC, sn.notification_created_at ASC
        LIMIT 100
    `

	rows, err := ns.db.Raw(query).Rows()
	if err != nil {
		return nil, fmt.Errorf("failed to query pending notifications: %w", err)
	}
	defer rows.Close()

	for rows.Next() {
		var notification NotificationData
		var dataJSON string
		var deliveryMethodsJSON string

		err := rows.Scan(
			&notification.NotificationID,
			&notification.UserID,
			&notification.UserEmail,
			&notification.UserPhone,
			&notification.TelegramChatID,
			&notification.Title,
			&notification.Message,
			&dataJSON,
			&notification.Type,
			&deliveryMethodsJSON,
			&notification.CreatedAt,
			&notification.Priority,
			&notification.Template,
		)
		if err != nil {
			log.Printf("❌ Error scanning notification row: %v", err)
			continue
		}

		// Parse data JSON
		if dataJSON != "" {
			if err := json.Unmarshal([]byte(dataJSON), &notification.Data); err != nil {
				log.Printf("❌ Failed to parse notification data for %s: %v", notification.NotificationID, err)
				notification.Data = make(map[string]interface{})
			}
		} else {
			notification.Data = make(map[string]interface{})
		}

		// Parse delivery methods JSON
		if deliveryMethodsJSON != "" {
			if err := json.Unmarshal([]byte(deliveryMethodsJSON), &notification.DeliveryMethods); err != nil {
				log.Printf("❌ Failed to parse delivery methods for %s: %v", notification.NotificationID, err)
				notification.DeliveryMethods = []string{}
			}
		}

		notifications = append(notifications, notification)
	}

	return notifications, nil
}

// ProcessPendingNotifications processes all pending notifications
func (ns *NotificationService) ProcessPendingNotifications() error {
	log.Println("📬 Processing pending notifications...")

	notifications, err := ns.GetPendingNotifications()
	if err != nil {
		return fmt.Errorf("failed to get pending notifications: %w", err)
	}

	if len(notifications) == 0 {
		log.Println("✅ No pending notifications to process")
		return nil
	}

	log.Printf("📋 Found %d pending notifications", len(notifications))

	processedCount := 0
	failedCount := 0

	for _, notification := range notifications {
		if err := ns.processNotification(notification); err != nil {
			log.Printf("❌ Failed to process notification %s: %v", notification.NotificationID, err)
			failedCount++
			continue
		}
		processedCount++
	}

	log.Printf("✅ Processed %d notifications (%d failed)", processedCount, failedCount)
	return nil
}

func (ns *NotificationService) processNotification(notification NotificationData) error {
	log.Printf("📬 Processing notification %s for user %s", notification.NotificationID, notification.UserID)

	// Update status to processing
	if err := ns.updateNotificationStatus(notification.NotificationID, "processing", ""); err != nil {
		return fmt.Errorf("failed to update notification status: %w", err)
	}

	// Process each delivery method
	for _, method := range notification.DeliveryMethods {
		if err := ns.processDeliveryMethod(notification, method); err != nil {
			log.Printf("❌ Failed to process delivery method %s for notification %s: %v",
				method, notification.NotificationID, err)
			// Continue with other methods even if one fails
		}
	}

	return nil
}

func (ns *NotificationService) processDeliveryMethod(notification NotificationData, method string) error {
	switch method {
	case "email":
		return ns.processEmailDelivery(notification)
	case "sms":
		return ns.processSMSDelivery(notification)
	case "telegram":
		return ns.processTelegramDelivery(notification)
	case "push":
		return ns.processPushDelivery(notification)
	default:
		return fmt.Errorf("unknown delivery method: %s", method)
	}
}

func (ns *NotificationService) processEmailDelivery(notification NotificationData) error {
	if notification.UserEmail == "" {
		return fmt.Errorf("user email is empty")
	}

	emailPayload := EmailJobPayload{
		NotificationID: notification.NotificationID,
		UserID:         notification.UserID,
		Recipient:      notification.UserEmail,
		Subject:        notification.Title,
		Body:           notification.Message,
		Template:       notification.Template,
		Data:           notification.Data,
	}

	return ns.emailSender.SendEmail(emailPayload)
}

func (ns *NotificationService) processSMSDelivery(notification NotificationData) error {
	if notification.UserPhone == "" {
		return fmt.Errorf("user phone is empty")
	}

	smsPayload := SMSJobPayload{
		NotificationID: notification.NotificationID,
		UserID:         notification.UserID,
		PhoneNumber:    notification.UserPhone,
		Message:        notification.Message,
		Data:           notification.Data,
	}

	return ns.smsSender.SendSMS(smsPayload)
}

func (ns *NotificationService) processTelegramDelivery(notification NotificationData) error {
	if notification.TelegramChatID == "" {
		return fmt.Errorf("telegram chat ID is empty")
	}

	telegramPayload := TelegramJobPayload{
		NotificationID: notification.NotificationID,
		UserID:         notification.UserID,
		ChatID:         notification.TelegramChatID,
		Message:        notification.Message,
		Data:           notification.Data,
	}

	return ns.telegramSender.SendTelegram(telegramPayload)
}

func (ns *NotificationService) processPushDelivery(notification NotificationData) error {
	// Implement push notification logic here
	log.Printf("📱 Push notification not implemented yet for %s", notification.NotificationID)
	return nil
}

// Helper functions
func (ns *NotificationService) parseEmailJobPayload(payload interface{}) (EmailJobPayload, error) {
	var emailPayload EmailJobPayload

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return emailPayload, err
	}

	err = json.Unmarshal(jsonData, &emailPayload)
	return emailPayload, err
}

func (ns *NotificationService) parseSMSJobPayload(payload interface{}) (SMSJobPayload, error) {
	var smsPayload SMSJobPayload

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return smsPayload, err
	}

	err = json.Unmarshal(jsonData, &smsPayload)
	return smsPayload, err
}

func (ns *NotificationService) parseTelegramJobPayload(payload interface{}) (TelegramJobPayload, error) {
	var telegramPayload TelegramJobPayload

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return telegramPayload, err
	}

	err = json.Unmarshal(jsonData, &telegramPayload)
	return telegramPayload, err
}

func (ns *NotificationService) updateNotificationStatus(notificationID, status, errorMsg string) error {
	query := `
		UPDATE tbl_system_notifications 
		SET notification_status = ?, 
			notification_error = ?,
			notification_sent_at = CASE WHEN ? = 'sent' THEN NOW() ELSE notification_sent_at END,
			updated_at = NOW()
		WHERE notification_id = ?
	`

	return ns.db.Exec(query, status, errorMsg, status, notificationID).Error
}

// CreateNotification creates a new notification in the database
func (ns *NotificationService) CreateNotification(
	userID, title, message, notificationType, template string,
	deliveryMethods []string,
	data map[string]interface{},
	priority int,
) error {
	dataJSON, err := json.Marshal(data)
	if err != nil {
		return fmt.Errorf("failed to marshal notification data: %w", err)
	}

	deliveryMethodsJSON, err := json.Marshal(deliveryMethods)
	if err != nil {
		return fmt.Errorf("failed to marshal delivery methods: %w", err)
	}

	query := `
		INSERT INTO tbl_system_notifications (
			notification_id, recipient_user_id, notification_title, notification_message,
			notification_type, notification_template, delivery_methods, notification_data,
			notification_priority, notification_status, notification_created_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
	`

	notificationID := generateNotificationID()
	return ns.db.Exec(query,
		notificationID, userID, title, message, notificationType, template,
		string(deliveryMethodsJSON), string(dataJSON), priority,
	).Error
}

func generateNotificationID() string {
	return fmt.Sprintf("notif_%d", time.Now().UnixNano())
}
