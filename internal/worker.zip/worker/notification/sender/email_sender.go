// worker/notification/sender/email_sender.go
package sender

import (
	"cbs_backend/internal/service/interfaces"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"gorm.io/gorm"
)

type EmailSender struct {
	db           *gorm.DB
	emailService interfaces.EmailService
}

func NewEmailSender(db *gorm.DB, emailService interfaces.EmailService) *EmailSender {
	return &EmailSender{
		db:           db,
		emailService: emailService,
	}
}

// EmailJobPayload represents the payload for email jobs
type EmailJobPayload struct {
	NotificationID string                 `json:"notification_id,omitempty"`
	UserID         string                 `json:"user_id"`
	Recipient      string                 `json:"recipient"`
	Subject        string                 `json:"subject"`
	Body           string                 `json:"body"`
	Template       string                 `json:"template"`
	Data           map[string]interface{} `json:"data"`
	EmailType      string                 `json:"email_type"` // consultation_reminder, booking_confirmation, etc.
}

// SendEmail processes an email job
func (es *EmailSender) SendEmail(payload EmailJobPayload) error {
	log.Printf("📧 Processing email job for user %s (template: %s)", payload.UserID, payload.Template)

	// Route to appropriate email service method based on template/type
	ctx := context.Background()
	var err error

	switch payload.Template {
	case "consultation_reminder":
		err = es.sendConsultationReminder(ctx, payload)
	case "booking_confirmation":
		err = es.sendBookingConfirmation(ctx, payload)
	case "booking_approval":
		err = es.sendBookingApproval(ctx, payload)
	case "booking_cancellation":
		err = es.sendBookingCancellation(ctx, payload)
	case "welcome":
		err = es.sendWelcomeEmail(ctx, payload)
	case "email_verification":
		err = es.sendEmailVerification(ctx, payload)
	case "password_reset":
		err = es.sendPasswordReset(ctx, payload)
	case "notification":
		err = es.sendGenericNotification(ctx, payload)
	default:
		err = fmt.Errorf("unknown email template: %s", payload.Template)
	}

	if err != nil {
		log.Printf("❌ Failed to send email: %v", err)
		// Update notification status to failed if notification_id exists
		if payload.NotificationID != "" {
			es.updateNotificationStatus(payload.NotificationID, "failed", err.Error())
		}
		return err
	}

	log.Printf("✅ Email sent successfully to %s", payload.Recipient)

	// Update notification status to sent if notification_id exists
	if payload.NotificationID != "" {
		es.updateNotificationStatus(payload.NotificationID, "sent", "")
	}

	return nil
}

func (es *EmailSender) sendConsultationReminder(ctx context.Context, payload EmailJobPayload) error {
	// Parse consultation data from payload
	reminderData, err := es.parseConsultationReminderData(payload.Data)
	if err != nil {
		return fmt.Errorf("failed to parse consultation reminder data: %w", err)
	}

	// Determine if this is for user or expert
	if payload.EmailType == "consultation_reminder_user" {
		return es.emailService.SendConsultationBookingRemindersToUser(ctx, payload.UserID, reminderData)
	} else if payload.EmailType == "consultation_reminder_expert" {
		return es.emailService.SendConsultationBookingRemindersToExpert(ctx, payload.UserID, reminderData)
	}

	return fmt.Errorf("unknown consultation reminder type: %s", payload.EmailType)
}

func (es *EmailSender) sendBookingConfirmation(ctx context.Context, payload EmailJobPayload) error {
	// Parse booking data from payload
	bookingData, err := es.parseConsultationBookingData(payload.Data)
	if err != nil {
		return fmt.Errorf("failed to parse booking confirmation data: %w", err)
	}

	return es.emailService.SendConsultationBookingConfirmation(ctx, payload.UserID, bookingData)
}

func (es *EmailSender) sendBookingApproval(ctx context.Context, payload EmailJobPayload) error {
	// Parse booking data from payload
	bookingData, err := es.parseConsultationBookingData(payload.Data)
	if err != nil {
		return fmt.Errorf("failed to parse booking approval data: %w", err)
	}

	return es.emailService.SendConsultationBookingApprove(ctx, payload.UserID, bookingData)
}

func (es *EmailSender) sendBookingCancellation(ctx context.Context, payload EmailJobPayload) error {
	// Determine if this is for user or expert
	if payload.EmailType == "booking_cancellation_user" {
		cancellationData, err := es.parseConsultationCancellationDataForUser(payload.Data)
		if err != nil {
			return fmt.Errorf("failed to parse user cancellation data: %w", err)
		}
		return es.emailService.SendConsultationBookingCancelledForUser(ctx, payload.UserID, cancellationData)
	} else if payload.EmailType == "booking_cancellation_expert" {
		cancellationData, err := es.parseConsultationCancellationDataForExpert(payload.Data)
		if err != nil {
			return fmt.Errorf("failed to parse expert cancellation data: %w", err)
		}
		return es.emailService.SendConsultationBookingCancelledForExpert(ctx, payload.UserID, cancellationData)
	}

	return fmt.Errorf("unknown booking cancellation type: %s", payload.EmailType)
}

func (es *EmailSender) sendWelcomeEmail(ctx context.Context, payload EmailJobPayload) error {
	fullName, ok := payload.Data["full_name"].(string)
	if !ok {
		return fmt.Errorf("missing or invalid full_name in payload")
	}

	return es.emailService.SendWelcomeEmail(ctx, payload.UserID, payload.Recipient, fullName)
}

func (es *EmailSender) sendEmailVerification(ctx context.Context, payload EmailJobPayload) error {
	verificationToken, ok := payload.Data["verification_token"].(string)
	if !ok {
		return fmt.Errorf("missing or invalid verification_token in payload")
	}

	return es.emailService.SendEmailVerification(ctx, payload.UserID, payload.Recipient, verificationToken)
}

func (es *EmailSender) sendPasswordReset(ctx context.Context, payload EmailJobPayload) error {
	resetToken, ok := payload.Data["reset_token"].(string)
	if !ok {
		return fmt.Errorf("missing or invalid reset_token in payload")
	}

	return es.emailService.SendPasswordReset(ctx, payload.Recipient, resetToken)
}

func (es *EmailSender) sendGenericNotification(ctx context.Context, payload EmailJobPayload) error {
	// For generic notifications, we don't use the EmailService interface
	// but instead send a simple notification email
	// This would typically use a generic email sender
	log.Printf("📧 Sending generic notification email to %s: %s", payload.Recipient, payload.Subject)

	// Here you would implement the actual email sending logic
	// For now, we'll just log it as sent
	return nil
}

// Helper functions to parse data structures
func (es *EmailSender) parseConsultationReminderData(data map[string]interface{}) (interfaces.ConsultationReminderData, error) {
	var reminderData interfaces.ConsultationReminderData

	// Convert map to JSON and back to struct for type safety
	jsonData, err := json.Marshal(data)
	if err != nil {
		return reminderData, err
	}

	err = json.Unmarshal(jsonData, &reminderData)
	return reminderData, err
}

func (es *EmailSender) parseConsultationBookingData(data map[string]interface{}) (interfaces.ConsultationBookingData, error) {
	var bookingData interfaces.ConsultationBookingData

	jsonData, err := json.Marshal(data)
	if err != nil {
		return bookingData, err
	}

	err = json.Unmarshal(jsonData, &bookingData)
	return bookingData, err
}

func (es *EmailSender) parseConsultationCancellationDataForUser(data map[string]interface{}) (interfaces.ConsultationCancellationDataForUser, error) {
	var cancellationData interfaces.ConsultationCancellationDataForUser

	jsonData, err := json.Marshal(data)
	if err != nil {
		return cancellationData, err
	}

	err = json.Unmarshal(jsonData, &cancellationData)
	return cancellationData, err
}

func (es *EmailSender) parseConsultationCancellationDataForExpert(data map[string]interface{}) (interfaces.ConsultationCancellationDataForExpert, error) {
	var cancellationData interfaces.ConsultationCancellationDataForExpert

	jsonData, err := json.Marshal(data)
	if err != nil {
		return cancellationData, err
	}

	err = json.Unmarshal(jsonData, &cancellationData)
	return cancellationData, err
}

func (es *EmailSender) updateNotificationStatus(notificationID, status, errorMsg string) error {
	query := `
		UPDATE tbl_system_notifications 
		SET notification_status = ?, 
			notification_error = ?,
			notification_sent_at = CASE WHEN ? = 'sent' THEN NOW() ELSE notification_sent_at END,
			updated_at = NOW()
		WHERE notification_id = ?
	`

	return es.db.Exec(query, status, errorMsg, status, notificationID).Error
}

// ProcessEmailBatch processes a batch of email notifications
func (es *EmailSender) ProcessEmailBatch(batchData interface{}) error {
	log.Println("📧 Processing email batch...")

	// Parse batch data
	batch, ok := batchData.(map[string]interface{})
	if !ok {
		return fmt.Errorf("invalid batch data format")
	}

	emails, ok := batch["emails"].([]interface{})
	if !ok {
		return fmt.Errorf("missing or invalid emails in batch data")
	}

	successCount := 0
	failCount := 0

	for i, emailData := range emails {
		log.Printf("📧 Processing email %d of %d", i+1, len(emails))

		// Convert email data to EmailJobPayload
		payload, err := es.parseEmailJobPayload(emailData)
		if err != nil {
			log.Printf("❌ Failed to parse email %d: %v", i+1, err)
			failCount++
			continue
		}

		// Send email
		if err := es.SendEmail(payload); err != nil {
			log.Printf("❌ Failed to send email %d: %v", i+1, err)
			failCount++
			continue
		}

		successCount++

		// Add small delay to prevent overwhelming the email service
		time.Sleep(100 * time.Millisecond)
	}

	log.Printf("✅ Email batch completed: %d sent, %d failed", successCount, failCount)
	return nil
}

func (es *EmailSender) parseEmailJobPayload(emailData interface{}) (EmailJobPayload, error) {
	var payload EmailJobPayload

	jsonData, err := json.Marshal(emailData)
	if err != nil {
		return payload, fmt.Errorf("failed to marshal email data: %w", err)
	}

	err = json.Unmarshal(jsonData, &payload)
	if err != nil {
		return payload, fmt.Errorf("failed to unmarshal email data: %w", err)
	}

	return payload, nil
}

// ValidateEmailPayload validates the email payload before sending
func (es *EmailSender) ValidateEmailPayload(payload EmailJobPayload) error {
	if payload.UserID == "" {
		return fmt.Errorf("user_id is required")
	}

	if payload.Recipient == "" {
		return fmt.Errorf("recipient is required")
	}

	if payload.Subject == "" {
		return fmt.Errorf("subject is required")
	}

	if payload.Template == "" {
		return fmt.Errorf("template is required")
	}

	return nil
}
